from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def contacto(request):
    return render(request,'contacto.html')

def nosotros(request):
    return render(request,'nosotros.html')

def promo(request):
    return render(request,'promo.html')

def servicios(request):
    return render(request,'servicios.html')

def sucursales(request):
    return render(request,'sucursales.html')

def prueba(request):
    return render(request,'prueba.html')
