from django.urls import path
from . import views

urlpatterns = [
    path('',views.nosotros,name="nosotros"),
    path('contacto/', views.contacto, name='contacto'),
    path('promo/', views.promo, name='promo'),
    path('servicios/', views.servicios, name='servicios'),
    path('sucursales/', views.sucursales, name='sucursales'),
    path('prueba/', views.prueba, name='prueba'),


]
