from django.contrib import admin
from . models import Automoviles,Empleados,Sucursales,Servicios
# Register your models here.
admin.site.register(Automoviles)
admin.site.register(Empleados)
admin.site.register(Sucursales)
admin.site.register(Servicios)
