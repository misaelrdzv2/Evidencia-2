from django.db import models

# Create your models here.
class Automoviles(models.Model):
    marca = models.CharField(max_length=50)
    modelo = models.CharField(max_length=50)
    año = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    tipo = models.CharField(max_length=50)

class Empleados(models.Model):
    nombre = models.CharField(max_length=50)
    genero = models.CharField(max_length=50)
    direccion = models.CharField(max_length=50)
    telefono = models.CharField(max_length=50)
    departamento = models.CharField(max_length=50)

class Sucursales(models.Model):
    nombre_sucursal = models.CharField(max_length=50)
    id_sucursal = models.CharField(max_length=50)
    estado = models.CharField(max_length=50)
    direccion = models.CharField(max_length=50)
    telefono = models.CharField(max_length=50)

class Servicios(models.Model):
    nombre_servicio = models.CharField(max_length=50)
    reseñas = models.CharField(max_length=50)
    descripcion = models.CharField(max_length=50)
    precio = models.CharField(max_length=50)
    metodo_pago = models.CharField(max_length=50)

